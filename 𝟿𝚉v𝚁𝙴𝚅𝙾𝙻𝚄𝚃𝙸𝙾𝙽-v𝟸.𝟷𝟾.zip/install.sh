SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"
print_modname() {
  ui_print "  ░9░Z░  ░P░E░R░F░+░+░  ㊍ "
sleep 2
  ui_print " 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 2.0+ ( 尺乇ᐯㄖㄥㄩㄒ丨ㄖ几 )"
}
on_install() {
  ui_print " 𝗕𝘂𝗶𝗹𝗱 𝗗𝗮𝘁𝗲 : 26 - 11 - 2023"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  set_permissions
    sleep 3
    ui_print "╔⤚⤚⤚⤚⤚⤚⤚⤚⤚⤚✭⤙⤙⤙⤙⤙⤙⤙⤙⤙⤙╗"
    ui_print " ◨ Getting your device info.. ◧"
    sleep 2
    ui_print ""
    sleep 1
    ui_print " ⊳ Android version : $(getprop ro.build.version.release)"
    sleep 1
  ui_print " ⊳ Brand : $(getprop ro.product.system.manufacturer)"
  sleep 1
  ui_print " ⊳ Cpu : $(getprop ro.hardware)"
  sleep 1
  ui_print " ⊳ Model : $(getprop ro.product.model)"
  sleep 1
  ui_print " ⊳ Kernel : $(uname -r)"
  sleep 1
  ui_print " ⊳ Ram : $(free | grep Mem |  awk '{print $2}')"
  sleep 1
  ui_print ""
  ui_print " 〄 ░ 𝗚𝗲𝘁 𝗥𝗲𝗮𝗱𝘆 𝗳𝗼𝗿 𝗚𝗮𝗺𝗶𝗻𝗴 ░ 〄 "
  sleep 2
   ui_print "╚⤚⤚⤚⤚⤚⤚⤚⤚⤚⤚✭⤙⤙⤙⤙⤙⤙⤙⤙⤙⤙╝"
sleep 2
  ui_print ""
  ui_print "╔⤚⤚⤚⤚⤚⤚⤚⤚⤚⤚✭⤙⤙⤙⤙⤙⤙⤙⤙⤙⤙╗"
    ui_print "  Installing Tweaks ↻ ..  "
sleep 1
ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Changing Your Density To 320 "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Touch Improvement "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Fstrim Every Boot "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Kernel Tweaks "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Low Memory Killer "
 ui_print ""
 sleep 1
  ui_print " [ INFO ] ➠ Applying SkiaGL Rendering "
  ui_print ""
  sleep 1
 ui_print " [ INFO ] ➠ Applying TCP Tweaks "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Some Debugging Disabler "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying CPU Optimization "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying GPU Optimization "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying CPU Sync Disabler "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Modded I/O Settings "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Internet Tweaks "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Network Tweaks "
 ui_print ""
 sleep 1
 ui_print " [ INFO ] ➠ Applying Wifi Tweaks "
 ui_print ""
  ui_print "╚⤚⤚⤚⤚⤚⤚⤚⤚⤚⤚✭⤙⤙⤙⤙⤙⤙⤙⤙⤙⤙╝"
sleep 0.5
ui_print ""
  ui_print " ░ Done, Please reboot your device ░ (⁠ ⁠╹⁠▽⁠╹⁠ ⁠)"
sleep 2
  ui_print ""
}
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0755
  set_perm $MODPATH/system/bin/unity 0 0 0755 0755
  set_perm $MODPATH/system/etc/init.d/ 0 0 0755 0755
}

# 
