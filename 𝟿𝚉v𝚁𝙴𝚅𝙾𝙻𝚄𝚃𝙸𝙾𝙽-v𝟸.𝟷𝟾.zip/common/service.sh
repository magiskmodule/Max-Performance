#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
# This script will be executed in late_start service mode
#!/system/bin/sh

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.1.1.1:53

# Disable Kernel Panic And Kernel Printk
echo "0 0 0 0" > /proc/sys/kernel/printk
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "0" > /proc/sys/kernel/sched_tunable_scaling

# increase performance
echo 1 > /sys/devices/system/cpu/perf/enable
cat /sys/devices/system/cpu/perf/enable

# Disable CABC 
echo Disable CABC Mode for best experience
echo 0 > /sys/kernel/oppo_display/cabc
echo 0 > /sys/kernel/oppo_display/LCM_CABC

# Disable some debugging
echo 0 > /sys/kernel/ccci/debug

# POWERHAL SPORT MODE
echo Add some games to sport mode
echo -e "com.mobile.legends\ncom.tencent.ig\ncom.miHoYo.GenshinImpact\ncom.tencent.tmgp.pubgmhd\ncom.dts.freefireth\ncom.dts.freefiremax\njp.konami.pesam\ncom.pubg.newstate\ncom.garena.game.codm\ncom.pubg.imobile\ncom.ea.gp.apexlegendsmobilefps\ncom.riotgames.league.wildrift\ncom.tencent.tmgp.sgame\ncom.tencent.iglite\ncom.vng.pubgmobile\ncom.miHoYo.bh3oversea\ncom.pubg.krmobile\ncom.rekoo.pubgm\ncom.activision.callofduty.shooter\n" > /data/vendor/powerhal/smart

# TCP
echo TCP Congestion Control
echo cubic > /proc/sys/net/ipv4/tcp_congestion_control
cat /proc/sys/net/ipv4/tcp_congestion_control
echo Enable TCP low latency
echo 1 > /proc/sys/net/ipv4/tcp_low_latency

# disable iostats
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0rpmb/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable

# eas tweak
chmod 0644 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy6/scaling_governor
restorecon -R /sys/devices/system/cpu
echo "performance" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "performance" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor 

# cpu boost Tweaks
echo '0' > /sys/devices/system/cpu/isolated
echo '0' > /sys/devices/system/cpu/offline
echo '0' > /sys/devices/system/cpu/uevent
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer

# scheduler TWEAK
chmod 0644 /sys/block/sda/queue/*
chmod 0644 /sys/block/sdb/queue/*
chmod 0644 /sys/block/sdc/queue/*
echo "noop" > /sys/block/mmcblk0/queue/scheduler
echo "noop" > /sys/block/mmcblk1/queue/scheduler
echo "noop" > /sys/block/sda/queue/scheduler
echo "noop" > /sys/block/sdb/queue/scheduler
echo "noop" > /sys/block/sdc/queue/scheduler
chmod 0444 /dev/stune/foreground/*
chmod 0444 /proc/cpufreq/*
echo '35' > /dev/stune/foreground/schedtune.boost
echo '1' > /proc/cpufreq/cpufreq_cci_mode

# Zram Things

stop perfd
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '80' > /proc/sys/vm/overcommit_ratio
echo '150' > /proc/sys/vm/vfs_cache_pressure
echo '0' > /proc/sys/vm/extra_free_kbytes
echo '128' > /proc/sys/kernel/random/read_wakeup_threshold
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '4096' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '5' > /proc/sys/vm/dirty_ratio
echo '20' > /proc/sys/vm/dirty_background_ratio
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo "2560,5120,11520,25600,35840,38400" > /sys/module/lowmemorykiller/parameters/minfree
rm /data/system/perfd/default_values
start perfd

while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
busybox=$(find /data/adb/ -type f -name busybox | head -n 1)
$busybox swapoff /dev/block/zram0
echo "1" > /sys/block/zram0/reset
echo "4294967296" > /sys/block/zram0/disksize
$busybox mkswap /dev/block/zram0
$busybox swapon /dev/block/zram0

for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
    chmod 666 $i/enable
	echo 0 > $i/enable
	chmod 444 $i/enable
done ;
exit 0

# fstrim and things
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload